package com.bosch.coding;

import com.rabbitmq.client.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Consumer {
    private static final String EXCHANGE_NAME = "inventory";

    public static void main(String[] args) throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.exchangeDeclare(EXCHANGE_NAME, "topic");
        String queueName = channel.queueDeclare().getQueue();
        channel.queueBind(queueName, EXCHANGE_NAME, "warehouse.event");

        System.out.println(" [LISTENING] Waiting for messages. To exit press CTRL+C");

        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), "UTF-8");
            System.out.println(" [RECEIVED] Received '" + message + "'");

            WarehouseRequestEvent event = parseEvent(message);
            updateInventory(event);
        };

        channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {});
    }

    private static WarehouseRequestEvent parseEvent(String message) {
        message = message.replace("WarehouseRequestEvent{", "").replace("}", "");
        String[] parts = message.split(", ");
        String fruit = parts[0].split("=")[1];
        int quantity = Integer.parseInt(parts[1].split("=")[1]);
        String command = parts[2].split("=")[1];
        return new WarehouseRequestEvent(fruit, quantity, command);
    }

    private static void updateInventory(WarehouseRequestEvent event) {
        String url = "jdbc:postgresql://localhost:5432/inventory_management";
        String user = "username";
        String password = "password";

        String sql = "UPDATE inventory SET quantity = quantity + ? WHERE fruit = ?";

        if (event.getCommand().equals("remove")) {
            sql = "UPDATE inventory SET quantity = quantity - ? WHERE fruit = ?";
        }

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, event.getQuantity());
            pstmt.setString(2, event.getFruit());
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
