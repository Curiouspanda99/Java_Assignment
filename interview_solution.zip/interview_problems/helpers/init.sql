CREATE DATABASE inventory_management;

\c inventory_management;

CREATE TABLE inventory (
    item VARCHAR(255) PRIMARY KEY,
    quantity INT NOT NULL
);

INSERT INTO inventory (fruit, quantity) VALUES ('apples', 70);
INSERT INTO inventory (fruit, quantity) VALUES ('bananas', 40);
INSERT INTO inventory (fruit, quantity) VALUES ('coconuts', 20);
INSERT INTO inventory (fruit, quantity) VALUES ('dates', 30);
INSERT INTO inventory (fruit, quantity) VALUES ('elderberries', 15);
