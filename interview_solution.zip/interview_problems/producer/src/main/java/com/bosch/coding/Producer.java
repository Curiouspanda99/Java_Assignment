package com.bosch.coding;

import java.util.Random;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;

public class Producer {

    public final class WarehouseRequestEvent {
        private final String fruit;
        private final Integer quantity;
        private final String command;

        public WarehouseRequestEvent(String fruit, Integer quantity, String command) {
            this.fruit = fruit;
            this.quantity = quantity;
            this.command = command;
        }

        public String getFruit() {
            return fruit;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public String getCommand() {
            return command;
        }

        @Override
        public String toString() {
            return "WarehouseRequestEvent{" +
                   "fruit='" + fruit + '\'' +
                   ", quantity=" + quantity +
                   ", command='" + command + '\'' +
                   '}';
        }
    }

    public class WarehouseRequestEventFactory {
        private static final String[] fruits = {"apples", "bananas", "coconuts", "dates", "elderberries"};
        private static String[] commands = {"add", "remove"};
        private static Random RANDOM = new Random();

        public WarehouseRequestEvent createEvent() {
            return new WarehouseRequestEvent(
                fruits[RANDOM.nextInt(fruits.length)],
                RANDOM.nextInt(10),
                commands[RANDOM.nextInt(commands.length)]
            );
        }
    }

    private static final String EXCHANGE_NAME = "inventory";

    public static void main(String[] args) {
        Producer producer = new Producer();
        WarehouseRequestEventFactory factory = producer.new WarehouseRequestEventFactory();

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");

        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {
            channel.exchangeDeclare(EXCHANGE_NAME, "topic");

            while (true) {
                WarehouseRequestEvent event = factory.createEvent();
                String message = event.toString();
                channel.basicPublish(EXCHANGE_NAME, "warehouse.event", null, message.getBytes("UTF-8"));
                System.out.println(" [RECEIVED] Sent '" + message + "'");

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
