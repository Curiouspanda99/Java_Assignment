package com.bosch.coding;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProducerTest {

    @Test
    public void testWarehouseRequestEvent() {
        Producer.WarehouseRequestEvent event = new Producer().new WarehouseRequestEvent("apples", 5, "add");
        assertEquals("apples", event.getFruit());
        assertEquals(5, event.getQuantity());
        assertEquals("add", event.getCommand());
    }

    @Test
    public void testWarehouseRequestEventFactory() {
        Producer.WarehouseRequestEventFactory factory = new Producer().new WarehouseRequestEventFactory();
        Producer.WarehouseRequestEvent event = factory.createEvent();
        assertNotNull(event);
        assertNotNull(event.getFruit());
        assertNotNull(event.getCommand());
        assertTrue(event.getQuantity() >= 0 && event.getQuantity() < 10);
    }
    @Test
    public void testSendEvent() throws Exception {
        // Mock RabbitMQ Channel
        Channel channel = mock(Channel.class);

        // Create a producer instance
        Producer producer = new Producer();
        Producer.WarehouseRequestEventFactory factory = producer.new WarehouseRequestEventFactory();
        Producer.WarehouseRequestEvent event = factory.createEvent();

        // Convert the event to a string and send it to RabbitMQ
        String message = event.toString();
        channel.basicPublish("inventory", "warehouse.event", null, message.getBytes("UTF-8"));

        // Verify that the publish method was called with correct parameters
        verify(channel, times(1)).basicPublish("inventory", "warehouse.event", null, message.getBytes("UTF-8"));
    }
    
}